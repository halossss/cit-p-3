const fs = require('fs');
const fastify = require('fastify')({ logger: true });
const { coinCount } = require('./p3-module.js');

fastify.get('/', (request, reply) => {
    readFil();
    fs.readFile(`${__dirname}/index.html`, (err, data) => {
        if (err) {
            reply
                .code(500)
                .header('Content-Type', 'html')
                .send('<h1>Server Error</h1>');
        } else {
            reply
                .code(200)
                .header('Content-Type', 'html')
                .send(data);
        }
    });
});

fastify.get('/coins', (request, reply) => {
    if (err) {
        reply
            .code(500)
            .header('Content-Type', 'application/json')
            .send({ error: 'An error occurred' });
    } else {
        const { denom = 0, count = 0 } = request.query;
        const coinValue = coinCount({ denom, count });
        reply
            .code(200)
            .header('Content-Type', 'application/json')
            .send({ value: coinValue });
    }
})


fastify.get('/coins', (request, reply) => {
    const { option } = request.query;
    let coinValue = 0;

    switch (option) {
        case '1':
            coinValue = coinCount({ denom: 5, count: 3 }, { denom: 10, count: 2 });
            break;
        case '2':
            coinValue = coinCount(...coins);
            break;
        case '3':
            coinValue = coinCount(coins);
            break;
        default:
            coinValue = 0
    }

    if (coinValue === 0) {
        reply
            .code(200)
            .header('Content-Type', 'html')
            .send(`<h2>Invalid option value</h2><br /><a href="/">Home</a>`);
    } else {
        reply
            .code(200)
            .header('Content-Type', 'html')
            .send(`<h2>Option ${option} value is ${coinValue}</h2><br /><a href="/">Home</a>`);
    }
});

fastify.listen(8080, 'localhost', (err, address) => {
    if (err) {
        console.error(err);
        process.exit(1);
    }
    console.log(`Server listening on ${address}`);
});