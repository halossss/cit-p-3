function validDenomination(coin) { if ([1, 5, 10, 25, 50, 100].indexOf(coin) !== -1) {return true;} else { return false; }}

function valueFromCoinObject(obj) {
    const {denom = 0, count = 0} = obj;
    return denom * count;
}

//used copilot to help me understand how to code this function
function valueFromArray(arr) {
    return arr.reduce((accumulator, currentValue) => {
        if (Array.isArray(currentValue)) {
            return accumulator + valueFromArray(currentValue);
        } else {
            return accumulator + valueFromCoinObject(currentValue);
        }
    }, 0);
}

function coinCount(...coinage) {
    let result = valueFromArray(coinage);
    return result;
}
// console.log("{}", coinCount({denom: 5, count: 3}));
// console.log("{}s", coinCount({denom: 5, count: 3},{denom: 10, count: 2}));
// const coins = [{denom: 25, count: 2},{denom: 1, count: 7}];
// console.log("...[{}]", coinCount(...coins));
// console.log("[{}]", coinCount(coins)); 